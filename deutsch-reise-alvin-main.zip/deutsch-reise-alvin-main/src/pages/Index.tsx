
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  GraduationCap, 
  Users, 
  Clock, 
  Calendar, 
  CheckCircle, 
  MessageCircle, 
  Instagram,
  Star,
  Globe,
  BookOpen,
  Award,
  Zap
} from "lucide-react";

const Index = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  const features = [
    "Kuliah di Eropa tanpa biaya",
    "Ikut program Ausbildung, AuPair, dan FSJ", 
    "Cari kerja dengan gaji tinggi",
    "Terbuka mulus dari D1 & wawancara beasiswa",
    "Peluang skill bahasa asing yang jarang dikuasai orang lain"
  ];

  const benefits = [
    {
      icon: <BookOpen className="w-6 h-6" />,
      title: "Dasar Jerman (Salam, Angka, Alfabet)",
      description: "Fondasi kuat dari nol"
    },
    {
      icon: <Zap className="w-6 h-6" />,
      title: "Tata Bahasa A1 Dijamin Paham!",
      description: "Artikel, kata kerja, struktur kalimat dasar—mudah dipahami"
    },
    {
      icon: <MessageCircle className="w-6 h-6" />,
      title: "Komunikasi Praktis Sehari-hari",
      description: "Arah, belanja, makan, interaksi umum"
    },
    {
      icon: <Users className="w-6 h-6" />,
      title: "Latihan Interaktif",
      description: "Teks, audio, video untuk pemahaman mendalam"
    },
    {
      icon: <Award className="w-6 h-6" />,
      title: "Simulasi Ujian A1 & Strategi Ampuh",
      description: "Tips & trik dari pengalaman langsung agar percaya diri"
    }
  ];

  const perfectFor = [
    "Bermimpi karir/studi di Jerman? Bahasa Jerman kuncinya.",
    "Pemula total yang butuh panduan jelas, langkah demi langkah.",
    "Siap ujian A1 Goethe, butuh bimbingan & tips jitu.",
    "Suka belajar tatap muka, interaktif, dan nyaman."
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-green-50">
      {/* Header */}
      <header className="sticky top-0 bg-white/80 backdrop-blur-md border-b border-green-100 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-to-br from-green-600 to-green-700 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">D</span>
              </div>
              <span className="font-bold text-xl text-gray-800">Super Deutsch</span>
            </div>
            <Button 
              className="bg-green-600 hover:bg-green-700 text-white shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105"
              onClick={() => window.open('https://wa.me/', '_blank')}
            >
              <MessageCircle className="w-4 h-4 mr-2" />
              Daftar Sekarang
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-green-50/30 to-transparent"></div>
        <div className="container mx-auto px-4 relative">
          <div className={`text-center max-w-4xl mx-auto transition-all duration-1000 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
            <Badge className="mb-6 bg-green-100 text-green-800 hover:bg-green-200 transition-colors duration-300">
              <Globe className="w-4 h-4 mr-2" />
              Level A1 - Pemula
            </Badge>
            <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-gray-800 via-green-700 to-gray-800 bg-clip-text text-transparent">
              Bahasa Jerman Bisa Jadi Tiket Masa Depanmu
            </h1>
            <p className="text-xl text-gray-600 mb-8 leading-relaxed">
              Jerman bukan cuma soal mobil mewah dan roti. Negara ini punya sistem pendidikan terbaik, 
              dan banyak kampusnya yang bebas biaya kuliah untuk mahasiswa internasional.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                className="bg-green-600 hover:bg-green-700 text-white shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105"
                onClick={() => window.open('https://wa.me/', '_blank')}
              >
                <MessageCircle className="w-5 h-5 mr-2" />
                Mulai Belajar Sekarang
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="border-green-600 text-green-600 hover:bg-green-50 transition-all duration-300 hover:scale-105"
              >
                <BookOpen className="w-5 h-5 mr-2" />
                Lihat Program
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gray-800">
              Bisa Bahasa Jerman bikin lo punya akses lebih besar buat:
            </h2>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => (
              <Card 
                key={index} 
                className={`p-6 hover:shadow-lg transition-all duration-500 hover:scale-105 border-green-100 hover:border-green-200 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
                style={{ transitionDelay: `${index * 100}ms` }}
              >
                <div className="flex items-start gap-3">
                  <CheckCircle className="w-6 h-6 text-green-600 mt-1 flex-shrink-0" />
                  <p className="text-gray-700 font-medium">{feature}</p>
                </div>
              </Card>
            ))}
          </div>
          <div className="text-center mt-12">
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Bahasa Jerman dipakai oleh lebih dari 100 juta orang. 
              Kalau lo bisa dikit aja, itu udah ngebuka pintu ke dunia yang lebih luas.
            </p>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-20 bg-gradient-to-br from-green-50 to-slate-50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <Card className="p-8 md:p-12 shadow-xl border-0 bg-white/80 backdrop-blur-sm">
              <div className="text-center mb-8">
                <div className="w-24 h-24 bg-gradient-to-br from-green-600 to-green-700 rounded-full mx-auto mb-6 flex items-center justify-center shadow-lg">
                  <span className="text-white font-bold text-2xl">A</span>
                </div>
                <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-800">Kenalan Dulu Yuk!</h2>
              </div>
              <div className="text-center space-y-4">
                <p className="text-lg text-gray-700">
                  Hai! Saya <strong className="text-green-700">Alvin Ramadhan Putra Prasetya</strong>. 
                  Saya di sini untuk membimbing Anda menguasai Bahasa Jerman.
                </p>
                <p className="text-lg text-gray-700">
                  Saya bukan hanya mentor, tapi teman seperjalanan Anda. 
                  Saya mengerti betul rasanya memulai dari nol, karena saya pernah di posisi Anda.
                </p>
                <p className="text-lg font-medium text-green-700">
                  Bersama saya, belajar Jerman jadi menyenangkan dan efektif.
                </p>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Perfect For Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gray-800">
              Program Ini Sempurna Untukmu Jika Kamu:
            </h2>
          </div>
          <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            {perfectFor.map((item, index) => (
              <Card 
                key={index} 
                className="p-6 hover:shadow-lg transition-all duration-500 hover:scale-105 border-green-100 hover:border-green-200"
              >
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <Star className="w-4 h-4 text-green-600" />
                  </div>
                  <p className="text-gray-700 font-medium">{item}</p>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* What You Get Section */}
      <section className="py-20 bg-gradient-to-br from-slate-50 to-green-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gray-800">
              Apa yang Akan Kamu Dapatkan:
            </h2>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {benefits.map((benefit, index) => (
              <Card 
                key={index} 
                className="p-8 hover:shadow-xl transition-all duration-500 hover:scale-105 border-0 bg-white/80 backdrop-blur-sm group"
              >
                <div className="text-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-green-100 to-green-200 rounded-full mx-auto mb-6 flex items-center justify-center group-hover:from-green-200 group-hover:to-green-300 transition-all duration-300">
                    <div className="text-green-600">
                      {benefit.icon}
                    </div>
                  </div>
                  <h3 className="text-xl font-bold mb-3 text-gray-800">{benefit.title}</h3>
                  <p className="text-gray-600">{benefit.description}</p>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Course Details Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gray-800">
              Belajar Bareng dari Nol, Gak Perlu Takut Gagal
            </h2>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
            <Card className="p-8 text-center hover:shadow-lg transition-all duration-300 hover:scale-105 border-green-100">
              <Calendar className="w-12 h-12 text-green-600 mx-auto mb-4" />
              <h3 className="text-xl font-bold mb-2 text-gray-800">12 Pertemuan Total</h3>
              <p className="text-gray-600">Selama 4 minggu intensif</p>
            </Card>
            <Card className="p-8 text-center hover:shadow-lg transition-all duration-300 hover:scale-105 border-green-100">
              <Globe className="w-12 h-12 text-green-600 mx-auto mb-4" />
              <h3 className="text-xl font-bold mb-2 text-gray-800">Via Zoom</h3>
              <p className="text-gray-600">3x seminggu, belajar dari rumah</p>
            </Card>
            <Card className="p-8 text-center hover:shadow-lg transition-all duration-300 hover:scale-105 border-green-100">
              <Award className="w-12 h-12 text-green-600 mx-auto mb-4" />
              <h3 className="text-xl font-bold mb-2 text-gray-800">E-Sertifikat</h3>
              <p className="text-gray-600">Dapat sertifikat setelah lulus</p>
            </Card>
          </div>
        </div>
      </section>

      {/* Certifications Section */}
      <section className="py-20 bg-gradient-to-br from-green-50 to-slate-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gray-800">Sertifikasi Saya</h2>
          </div>
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <Card className="p-8 hover:shadow-xl transition-all duration-500 hover:scale-105 border-0 bg-white/80 backdrop-blur-sm">
              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-yellow-400 to-yellow-500 rounded-full mx-auto mb-6 flex items-center justify-center">
                  <Award className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold mb-4 text-gray-800">Goethe-Zertifikat A1</h3>
                <p className="text-gray-600 mb-4">
                  Mendapatkan predikat "Sangat baik" dan mendapatkan poin (91/100)
                </p>
                <Button variant="outline" className="border-green-600 text-green-600 hover:bg-green-50">
                  Lihat Sertifikat
                </Button>
              </div>
            </Card>
            <Card className="p-8 hover:shadow-xl transition-all duration-500 hover:scale-105 border-0 bg-white/80 backdrop-blur-sm">
              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-blue-400 to-blue-500 rounded-full mx-auto mb-6 flex items-center justify-center">
                  <Star className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold mb-4 text-gray-800">Altissia Assessment</h3>
                <p className="text-gray-600 mb-4">
                  Meraih level B2 (total) & C1 (Listening)
                </p>
                <Button variant="outline" className="border-green-600 text-green-600 hover:bg-green-50">
                  Lihat Sertifikat
                </Button>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gray-800">Jadwal dan Biaya</h2>
          </div>
          <Card className="max-w-4xl mx-auto p-8 md:p-12 shadow-xl border-2 border-green-200 hover:shadow-2xl transition-all duration-500">
            <div className="grid md:grid-cols-3 gap-8 mb-8">
              <div className="text-center">
                <Calendar className="w-12 h-12 text-green-600 mx-auto mb-4" />
                <h3 className="text-xl font-bold mb-2 text-gray-800">Senin – Rabu – Jumat</h3>
                <p className="text-gray-600">Jadwal rutin mingguan selama 4 Minggu</p>
              </div>
              <div className="text-center">
                <Clock className="w-12 h-12 text-green-600 mx-auto mb-4" />
                <h3 className="text-xl font-bold mb-2 text-gray-800">19.00 – 20.00 WIB</h3>
                <p className="text-gray-600">60 menit per sesi</p>
              </div>
              <div className="text-center">
                <Globe className="w-12 h-12 text-green-600 mx-auto mb-4" />
                <h3 className="text-xl font-bold mb-2 text-gray-800">Via Zoom Meeting</h3>
                <p className="text-gray-600">Online dari rumah</p>
              </div>
            </div>
            <div className="text-center border-t pt-8">
              <div className="mb-6">
                <span className="text-5xl font-bold text-green-600">Rp240.000</span>
                <p className="text-xl text-gray-600 mt-2">untuk 12 pertemuan lengkap</p>
                <p className="text-sm text-gray-500 mt-2">
                  Catatan: Semua pembayaran dilakukan sekali di awal melalui transfer.
                </p>
              </div>
              <Button 
                size="lg" 
                className="bg-green-600 hover:bg-green-700 text-white shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105"
                onClick={() => window.open('https://wa.me/', '_blank')}
              >
                <MessageCircle className="w-5 h-5 mr-2" />
                Daftar Sekarang via WhatsApp
              </Button>
            </div>
          </Card>
        </div>
      </section>

      {/* Class Features Section */}
      <section className="py-20 bg-gradient-to-br from-slate-50 to-green-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gray-800">
              Bukan Cuma Nonton, Tapi Beneran Belajar
            </h2>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
            {[
              "Format kelas kecil, barengan (bukan privat 1 on 1)",
              "Suasana santai tapi terarah",
              "Setiap sesi ada review dan latihan",
              "Materi dikirim PDF",
              "Kelas dimulai serempak (batch)"
            ].map((feature, index) => (
              <Card 
                key={index} 
                className="p-6 hover:shadow-lg transition-all duration-500 hover:scale-105 border-green-100 hover:border-green-200 bg-white/80 backdrop-blur-sm"
              >
                <div className="flex items-start gap-3">
                  <CheckCircle className="w-6 h-6 text-green-600 mt-1 flex-shrink-0" />
                  <p className="text-gray-700 font-medium">{feature}</p>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-green-600 to-green-700">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-8">
            Siap Mulai Belajar Bahasa Jerman?
          </h2>
          <Button 
            size="lg" 
            className="bg-white text-green-700 hover:bg-gray-100 shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-110 text-lg px-8 py-6"
            onClick={() => window.open('https://wa.me/', '_blank')}
          >
            <MessageCircle className="w-6 h-6 mr-3" />
            Hubungi via WhatsApp
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="flex items-center gap-2 mb-6 md:mb-0">
              <div className="w-8 h-8 bg-gradient-to-br from-green-600 to-green-700 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">D</span>
              </div>
              <span className="font-bold text-xl">Super Deutsch</span>
            </div>
            <div className="flex items-center gap-6">
              <Button 
                variant="ghost" 
                size="sm" 
                className="text-white hover:text-green-400 hover:bg-gray-800 transition-all duration-300"
                onClick={() => window.open('https://wa.me/', '_blank')}
              >
                <MessageCircle className="w-5 h-5 mr-2" />
                WhatsApp
              </Button>
              <Button 
                variant="ghost" 
                size="sm" 
                className="text-white hover:text-green-400 hover:bg-gray-800 transition-all duration-300"
                onClick={() => window.open('https://instagram.com/', '_blank')}
              >
                <Instagram className="w-5 h-5 mr-2" />
                Instagram
              </Button>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center">
            <p className="text-gray-400">© 2025 - Super Deutsch by Alvin</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
